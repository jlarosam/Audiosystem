<footer class="footer__secion">
    <div class="parte1">
        <div class="texto">
            <h1 class="tituloEmpresa">Company Name</h1>
            <p class="parrafoFooter">
                Lorem ipsum dolor sit amet, consectetur
                adipiscing elit, sed do eiusmod tempor
                incididunt ut labore et dolore magna aliqua.
            </p>
            <div class="iconos">
                <a href="#" class="links__iconos">
                    <i class="bi bi-facebook"></i>
                </a>
                <a href="" class="links__iconos">
                    <i class="bi bi-twitter-x"></i>
                </a>
                <a href="" class="links__iconos">
                    <i class="bi bi-instagram"></i>
                </a>
                <a href="" class="links__iconos">
                    <i class="bi bi-tiktok"></i>
                </a>
            </div>
        </div>

        <div class="links__footer">
            <ul class="footer__menu">
                <li><a href="#">Inicio</a></li>
                <li><a href="#">Acerca de</a></li>
                <li><a href="#">Servicios</a></li>
                <li><a href="#">Contacto</a></li>
            </ul>
        </div>
    </div>
    <div class="parte2">
        <img src="img/logo.jpeg" alt="logo">
        <p>© 2023 Lorem Ipsum. All Rights Reserved.</p>
    </div>
</footer>